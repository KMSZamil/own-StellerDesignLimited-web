<section id="why-us" class="wow fadeIn">
    <div class="container">
      <header class="section-header">
        <h3>Why choose us?</h3>
        <p>We can say we are the best. Because we have a strong them who can break all the barriers of our way.</p>
      </header>

      <div class="row row-eq-height justify-content-center">

        <div class="col-lg-4 mb-4">
          <div class="card wow bounceInUp">
              <i class="fa fa-diamond"></i>
            <div class="card-body">
              <h5 class="card-title">Speed Up Delivery</h5>
              <p class="card-text">Our dedicated developers can help you meet challenging deadlines more cost-effectively, compared with in-house development. We have many expert brains to give you the tried-and-tested delivery framework that guarantees consistency and minimizes bottlenecks.</p>
              
            </div>
          </div>
        </div>

        <div class="col-lg-4 mb-4">
          <div class="card wow bounceInUp">
              <i class="fa fa-language"></i>
            <div class="card-body">
              <h5 class="card-title">100% Satisfaction Guaranteed</h5>
              <p class="card-text">We have a strong client base who get help from us by our work. We have the tech knowledge coupled with the business understanding that allows us to create unique solutions that power enterprises, their employees, and customers every day.</p>
              
            </div>
          </div>
        </div>

        <div class="col-lg-4 mb-4">
          <div class="card wow bounceInUp">
              <i class="fa fa-object-group"></i>
            <div class="card-body">
              <h5 class="card-title">24/7 Communication</h5>
              <p class="card-text">You can find us at any time. Because we have all the expertise to solve any crucial problems, we always stand by your side. That's why you can choose us to grow your business.</p>
              
            </div>
          </div>
        </div>

      </div>

      <div class="row counters">

        <div class="col-lg-3 col-6 text-center">
          <span data-toggle="counter-up">274</span>
          <p>Clients</p>
        </div>

        <div class="col-lg-3 col-6 text-center">
          <span data-toggle="counter-up">421</span>
          <p>Projects</p>
        </div>

        <div class="col-lg-3 col-6 text-center">
          <span data-toggle="counter-up">1,364</span>
          <p>Hours Of Support</p>
        </div>

        <div class="col-lg-3 col-6 text-center">
          <span data-toggle="counter-up">18</span>
          <p>Hard Workers</p>
        </div>

      </div>

    </div>
  </section><?php /**PATH E:\wamp64\www\fzr_technology\resources\views/layouts/frontend/why_us.blade.php ENDPATH**/ ?>