<section id="portfolio" class="clearfix">
    <div class="container">

        <header class="section-header">
            <h3 class="section-title">Our Portfolio</h3>
        </header>

        <div class="row">
            <div class="col-lg-12">
                <ul id="portfolio-flters">
                    <li data-filter="*" class="filter-active">All</li>
                    <li data-filter=".filter-app">App</li>
                    <li data-filter=".filter-web">Web</li>
                    <li data-filter=".filter-card">Design</li>
                </ul>
            </div>
        </div>

        <div class="row portfolio-container">
            <div class="col-lg-4 col-md-6 portfolio-item filter-app">
                <?php $__currentLoopData = $projects_app; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="portfolio-wrap m-2">
                        <img src="<?php echo e(asset('storage/' . $row->image_path)); ?>" class="img-fluid" alt="">
                        <div class="portfolio-info">
                            <h4><a href="#" style="text-decoration: none;"><?php echo e($row->name); ?></a></h4>
                            <p>App</p>
                            <div>
                                <a href="<?php echo e(asset('storage/' . $row->image_path)); ?>" data-lightbox="portfolio"
                                    data-title="<?php echo e($row->name); ?>" class="link-preview" title="Preview"><i
                                        class="ion ion-eye"></i></a>
                                <?php if($row->project_url_1 != null): ?>
                                    <a href="<?php echo e($row->project_url_1); ?>" class="link-details" target="_blank"
                                        title="More Details"><i class="ion ion-android-open"></i></a>
                                <?php endif; ?>
                                <?php if($row->project_url_2 != null): ?>
                                    <a href="<?php echo e($row->project_url_2); ?>" class="link-details" target="_blank"
                                        title="More Details"><i class="ion ion-android-open"></i></a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="col-lg-4 col-md-6 portfolio-item filter-web">
                <?php $__currentLoopData = $projects_web; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="portfolio-wrap m-2">
                        <img src="<?php echo e(asset('storage/' . $row->image_path)); ?>" class="img-fluid" alt="">
                        <div class="portfolio-info">
                            <h4><a href="#" style="text-decoration: none;"><?php echo e($row->name); ?></a></h4>
                            <p>App</p>
                            <div>
                                <a href="<?php echo e(asset('storage/' . $row->image_path)); ?>" data-lightbox="portfolio"
                                    data-title="<?php echo e($row->name); ?>" class="link-preview" title="Preview"><i
                                        class="ion ion-eye"></i></a>
                                <?php if($row->project_url_1 != null): ?>
                                    <a href="<?php echo e($row->project_url_1); ?>" class="link-details" target="_blank"
                                        title="More Details"><i class="ion ion-android-open"></i></a>
                                <?php endif; ?>
                                <?php if($row->project_url_2 != null): ?>
                                    <a href="<?php echo e($row->project_url_2); ?>" class="link-details" target="_blank"
                                        title="More Details"><i class="ion ion-android-open"></i></a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="col-lg-4 col-md-6 portfolio-item filter-card">
                <?php $__currentLoopData = $projects_design; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="portfolio-wrap m-2">
                        <img src="<?php echo e(asset('storage/' . $row->image_path)); ?>" class="img-fluid" alt="">
                        <div class="portfolio-info">
                            <h4><a href="#" style="text-decoration: none;"><?php echo e($row->name); ?></a></h4>
                            <p>App</p>
                            <div>
                                <a href="<?php echo e(asset('storage/' . $row->image_path)); ?>" data-lightbox="portfolio"
                                    data-title="<?php echo e($row->name); ?>" class="link-preview" title="Preview"><i
                                        class="ion ion-eye"></i></a>
                                <?php if($row->project_url_1 != null): ?>
                                    <a href="<?php echo e($row->project_url_1); ?>" class="link-details" target="_blank"
                                        title="More Details"><i class="ion ion-android-open"></i></a>
                                <?php endif; ?>
                                <?php if($row->project_url_2 != null): ?>
                                    <a href="<?php echo e($row->project_url_2); ?>" class="link-details" target="_blank"
                                        title="More Details"><i class="ion ion-android-open"></i></a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>





        </div>

    </div>
</section>
<?php /**PATH E:\wamp64\www\fzr_technology\resources\views/layouts/frontend/portfolio.blade.php ENDPATH**/ ?>