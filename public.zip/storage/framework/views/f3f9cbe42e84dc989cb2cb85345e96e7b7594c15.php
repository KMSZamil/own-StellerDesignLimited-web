<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title><?php echo $__env->yieldContent('page_title'); ?></title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicons -->
    <link href="<?php echo e(asset('assets/frontend/img/fzr_favicon.png')); ?>" rel="icon">
    <link href="<?php echo e(asset('assets/frontend/img/fzr-apple-touch-icon.png')); ?>" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Montserrat:300,400,500,700"
        rel="stylesheet">

    <!-- Bootstrap CSS File -->
    <link href="<?php echo e(asset('assets/frontend/lib/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!-- Libraries CSS Files -->
    <link href="<?php echo e(asset('assets/frontend/lib/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/frontend/lib/animate/animate.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/frontend/lib/ionicons/css/ionicons.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/frontend/lib/owlcarousel/assets/owl.carousel.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/frontend/lib/lightbox/css/lightbox.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/toastr/toastr.min.css')); ?>">

    <!-- Main Stylesheet File -->
    <link href="<?php echo e(asset('assets/frontend/css/style.css')); ?>" rel="stylesheet">


    <?php $__env->startPush('css'); ?>

    </head>

    <body>

        <?php echo $__env->make('layouts.frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <main id="main">

            <?php echo $__env->yieldContent('main_section'); ?>

        </main>

        <?php echo $__env->make('layouts.frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Uncomment below i you want to use a preloader -->
        <!-- <div id="preloader"></div> -->

        <!-- JavaScript Libraries -->
        <script src="<?php echo e(asset('assets/frontend/lib/jquery/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/frontend/lib/jquery/jquery-migrate.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/frontend/lib/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/frontend/lib/easing/easing.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/frontend/lib/mobile-nav/mobile-nav.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/frontend/lib/wow/wow.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/frontend/lib/waypoints/waypoints.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/frontend/lib/counterup/counterup.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/frontend/lib/owlcarousel/owl.carousel.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/frontend/lib/isotope/isotope.pkgd.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/frontend/lib/lightbox/js/lightbox.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/vendors/toastr/toastr.min.js')); ?>"></script>
        <?php echo Toastr::message(); ?>

        <!-- Contact Form JavaScript File -->
        <script src="<?php echo e(asset('assets/frontend/contactform/contactform.js')); ?>"></script>

        <!-- Template Main Javascript File -->
        <script src="<?php echo e(asset('assets/frontend/js/main.js')); ?>"></script>

        <?php $__env->startPush('js'); ?>

        </body>

        </html>
<?php /**PATH E:\wamp64\www\fzr_technology\resources\views/layouts/frontend/master.blade.php ENDPATH**/ ?>