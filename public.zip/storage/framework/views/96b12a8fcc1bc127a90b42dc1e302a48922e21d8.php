

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/bootstrap-datepicker/bootstrap-datepicker.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('page_title'); ?>
    Project Edit
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <nav class="page-breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('projects.index')); ?>">Project</a></li>
            <li class="breadcrumb-item active" aria-current="page">Project Edit</li>
        </ol>
    </nav>

    <div class="row">
        <div class="col-sm-12">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul class="text-center">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div><?php echo e($error); ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
        </div>
        <div class="col-md-12 stretch-card">
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title">Project Form</h6>
                    <form action="<?php echo e(route('projects.update', $project->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label">Name</label>
                                    <input type="text" class="form-control" name="name" id="name" placeholder="Enter Name" value="<?php echo e($project->name); ?>">
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label">Portfolio</label>
                                    <select class="form-control mb-3" name="portfolio_id" id="portfolio_id" required>
                                        <option value="">Select</option>
                                        <?php $__currentLoopData = $portfolio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($row->id); ?>"
                                                <?php echo e(isset($project->portfolio_id) && $project->portfolio_id == $row->id ? 'selected' : ''); ?>>
                                                <?php echo e($row->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label">Project Url 1</label>
                                    <input type="text" class="form-control" name="project_url_1" id="project_url_1" placeholder="Enter Project URL 1" value="<?php echo e($project->project_url_1); ?>">
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label">Project Url 2</label>
                                    <input type="text" class="form-control" name="project_url_2" id="project_url_2" placeholder="Enter Project URL 2" value="<?php echo e($project->project_url_2); ?>">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label class="control-label">Image</label>
                                    <input type="file" class="form-control" name="file" id="file"
                                        placeholder="Enter File">
                                    
                                </div>
                            </div>
                            <div class="col-sm-2">
                                <?php if(isset($project->image_path)): ?>
                                    <div class="col-sm-2">
                                        <div class="form-group">
                                            <a href="<?php echo e(asset('storage/' . $project->image_path)); ?>" target="_blank">
                                                <img width="100" src="<?php echo e(asset('storage/' . $project->image_path)); ?>" />
                                            </a>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="control-label">Status</label>
                                    <select class="form-control mb-3" name="active" required>
                                        <option value="Y" <?php echo e(isset($project->active) && $project->active=='Y' ? "selected" : ""); ?>>Active</option>
                                        <option value="N" <?php echo e(isset($project->active) && $project->active=='N' ? "selected" : ""); ?>>In-Active</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary submit">Submit Project</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('assets/vendors/bootstrap-datepicker/bootstrap-datepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datepicker_edit_custom.js')); ?>"></script>
    <script></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\fzr_technology\resources\views/projects/edit.blade.php ENDPATH**/ ?>