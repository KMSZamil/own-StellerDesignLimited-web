<footer class="footer d-flex flex-column flex-md-row align-items-center justify-content-between">
    <p class="text-muted text-center text-md-left">Copyright © <?php echo date('Y'); ?> <a href="#">K. M. Shawkat Zamil</a>. All rights reserved</p>
</footer>
<?php /**PATH E:\wamp64\www\fzr_technology\resources\views/layouts/footer.blade.php ENDPATH**/ ?>