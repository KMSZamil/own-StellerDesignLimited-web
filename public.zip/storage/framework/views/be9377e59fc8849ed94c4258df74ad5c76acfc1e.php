<header id="header" class="fixed-top">
<div class="container">

    <div class="logo float-left">
    <!-- Uncomment below if you prefer to use an image logo -->
    <!-- <h1 class="text-light"><a href="#header"><span>NewBiz</span></a></h1> -->
    <a href="<?php echo e(route('frontend.index')); ?>" class="scrollto"><img src="<?php echo e(asset('assets/frontend/img/fzr_logo.png')); ?>" alt="" class="img-fluid"></a>
    </div>

    <nav class="main-nav float-right d-none d-lg-block">
    <ul>
        <li class="active"><a href="<?php echo e(route('frontend.index')); ?> ">Home</a></li>
        <li><a href="#about">About Us</a></li>
        <li><a href="#services">Services</a></li>
        <li><a href="#portfolio">Portfolio</a></li>
        
        
        <li><a href="#contact">Contact Us</a></li>
    </ul>
    </nav>
    
</div>
</header>

<section id="intro" class="clearfix">
    <div class="container">

      <div class="intro-img">
        <img src="<?php echo e(asset('assets/frontend/img/intro-img.svg')); ?>" alt="" class="img-fluid">
      </div>

      <div class="intro-info">
        <h2>We provide<br><span>IT solutions</span><br>for your business!</h2>
        <div>
          <a href="#about" class="btn-get-started scrollto">Get Started</a>
          <a href="#services" class="btn-services scrollto">Our Services</a>
        </div>
      </div>

    </div>
  </section><?php /**PATH E:\wamp64\www\fzr_technology\resources\views/layouts/frontend/header.blade.php ENDPATH**/ ?>