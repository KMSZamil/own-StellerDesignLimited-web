<!DOCTYPE html>
<html lang="en">

<head>
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-2194451574476602"
        crossorigin="anonymous"></script>
    <title><?php echo $__env->yieldContent('page_title'); ?></title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link href="<?php echo e(asset('assets/frontend/styles/layout.css')); ?>" rel="stylesheet" type="text/css" media="all">


    <?php echo SEOMeta::generate(); ?>

    <?php echo OpenGraph::generate(); ?>

    <?php echo Twitter::generate(); ?>

    <?php echo JsonLd::generate(); ?>

    <style>
        html {
            scroll-behavior: smooth
        }
    </style>
    <?php echo $__env->yieldPushContent('css'); ?>

    </head>

    <body id="top">

        <?php echo $__env->make('layouts.frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <main id="main">

            <?php echo $__env->yieldContent('main_section'); ?>

        </main>

        <?php echo $__env->make('layouts.frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <a id="backtotop" href="#top"><i class="fas fa-chevron-up"></i></a>

        <script src="<?php echo e(asset('assets/frontend/scripts/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/frontend/scripts/jquery.backtotop.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/frontend/scripts/jquery.mobilemenu.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/frontend/scripts/jquery.easypiechart.min.js')); ?>"></script>
         <script src="<?php echo e(asset('assets/js/jquery_lazy/jquery.lazy.min.js')); ?>"></script>
         <script src="<?php echo e(asset('assets/js/jquery_lazy/jquery.lazy.plugins.min.js')); ?>"></script>

        <?php echo $__env->yieldPushContent('js'); ?>

        </body>

        </html>
<?php /**PATH D:\wamp64\www\steller_design\resources\views/layouts/frontend/master.blade.php ENDPATH**/ ?>