<section id="about">
    <div class="container">

      <header class="section-header">
        <h3>About Us</h3>
        <p>FZR Technology is a small group of enthusiastic people, who want to change society through their effort.</p>
      </header>

      <div class="row about-container">

        <div class="col-lg-6 content order-lg-1 order-2">
          <p>
            We develop websites and mobile apps for individuals or companies. We also make the road map to start a business on your own by giving all the It solutions they need.
          </p>

          <div class="icon-box wow fadeInUp">
            <div class="icon"><i class="fa fa-shopping-bag"></i></div>
            <h4 class="title"><a href="#">Web Application</a></h4>
            <p class="description">We build websites that solve our client's business challenges. In today's world, a website is the basic introduction of any business. That's why we build different types of websites like portfolio websites, inventory websites, e-commerce websites, etc.</p>
          </div>

          <div class="icon-box wow fadeInUp" data-wow-delay="0.2s">
            <div class="icon"><i class="fa fa-photo"></i></div>
            <h4 class="title"><a href="#">Mobile Application</a></h4>
            <p class="description">Mobile application is such type of medium that connects all the people of the globe at any second. We provide e-commerce apps, news apps, portfolio apps, or any kind of applications that clients required.</p>
          </div>

          <div class="icon-box wow fadeInUp" data-wow-delay="0.4s">
            <div class="icon"><i class="fa fa-bar-chart"></i></div>
            <h4 class="title"><a href="#">IT Solutions</a></h4>
            <p class="description">We provide different types of IT solutions that client want and which solves the client's problem area. We also provide all types of reporting panel which helps people to take any kinds of decisions for their business.</p>
          </div>

        </div>

        <div class="col-lg-6 background order-lg-2 order-1 wow fadeInUp">
          <img src="<?php echo e(asset('assets/frontend/img/about-img.svg')); ?>" class="img-fluid" alt="">
        </div>
      </div>

      

    </div>
  </section><?php /**PATH E:\wamp64\www\fzr_technology\resources\views/layouts/frontend/about_us.blade.php ENDPATH**/ ?>