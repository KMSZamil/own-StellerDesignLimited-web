<section id="services" class="section-bg">
    <div class="container">

      <header class="section-header">
        <h3>Services</h3>
        <p>We develop websites and mobile apps for individuals or companies. We also make the road map to start a business on your own by giving all the It solutions they need.</p>
      </header>

      <div class="row">

        <div class="col-md-6 col-lg-5 offset-lg-1 wow bounceInUp" data-wow-duration="1.4s">
          <div class="box">
            <div class="icon"><i class="ion-ios-analytics-outline" style="color: #ff689b;"></i></div>
            <h4 class="title"><a href="#">Website Developmet</a></h4>
            <p class="description">We build websites that solve our client's business challenges. In today's world, a website is the basic introduction of any business. That's why we build different types of websites like portfolio websites, inventory websites, e-commerce websites, etc.</p>
          </div>
        </div>
        <div class="col-md-6 col-lg-5 wow bounceInUp" data-wow-duration="1.4s">
          <div class="box">
            <div class="icon"><i class="ion-ios-bookmarks-outline" style="color: #e9bf06;"></i></div>
            <h4 class="title"><a href="#">Mobile Application Development</a></h4>
            <p class="description">Mobile application is such type of medium that connects all the people of the globe at any second. We provide e-commerce apps, news apps, portfolio apps, or any kind of applications that clients required.</p>
          </div>
        </div>

        <div class="col-md-6 col-lg-5 offset-lg-1 wow bounceInUp" data-wow-delay="0.1s" data-wow-duration="1.4s">
          <div class="box">
            <div class="icon"><i class="ion-ios-paper-outline" style="color: #3fcdc7;"></i></div>
            <h4 class="title"><a href="#">IT Solutions</a></h4>
            <p class="description">We provide different types of IT solutions that client want and which solves the client's problem area.</p>
          </div>
        </div>
        <div class="col-md-6 col-lg-5 wow bounceInUp" data-wow-delay="0.1s" data-wow-duration="1.4s">
          <div class="box">
            <div class="icon"><i class="ion-ios-speedometer-outline" style="color:#41cf2e;"></i></div>
            <h4 class="title"><a href="#">Reporting Panel</a></h4>
            <p class="description">We develop all types of reporting panel which helps people to take any kinds of decisions for their business. We suggest different types of customized reports to grow a company faster.</p>
          </div>
        </div>

        <div class="col-md-6 col-lg-5 offset-lg-1 wow bounceInUp" data-wow-delay="0.2s" data-wow-duration="1.4s">
          <div class="box">
            <div class="icon"><i class="ion-ios-world-outline" style="color: #d6ff22;"></i></div>
            <h4 class="title"><a href="#">Tranparency</a></h4>
            <p class="description">Our service is transparent in every corner. First, we show our clients what we can do, and then we evaluate the requirement in the price. We always try to keep our commitments.</p>
          </div>
        </div>
        <div class="col-md-6 col-lg-5 wow bounceInUp" data-wow-delay="0.2s" data-wow-duration="1.4s">
          <div class="box">
            <div class="icon"><i class="ion-ios-clock-outline" style="color: #4680ff;"></i></div>
            <h4 class="title"><a href="#">Timeliness</a></h4>
            <p class="description">Our leaders guides us by adding subtasks, creating milestones, building dependencies, calculating cost estimations, and more at the very beginning. </p>
          </div>
        </div>

      </div>

    </div>
  </section><?php /**PATH E:\wamp64\www\fzr_technology\resources\views/layouts/frontend/services.blade.php ENDPATH**/ ?>