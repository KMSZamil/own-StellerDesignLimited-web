<footer class="footer d-flex flex-column flex-md-row align-items-center justify-content-between">
    <p class="text-muted text-center text-md-left">Copyright © @php echo date('Y'); @endphp <a href="#">K. M. Shawkat Zamil</a>. All rights reserved</p>
</footer>
